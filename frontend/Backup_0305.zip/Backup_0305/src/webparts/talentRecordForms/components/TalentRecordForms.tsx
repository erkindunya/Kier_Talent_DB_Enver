import * as React from 'react';
import styles from './TalentRecordForms.module.scss';
import {ITalentRecordFormsProps} from './ITalentRecordFormsProps';
import {escape} from '@microsoft/sp-lodash-subset';
import {DefaultButton, IButtonProps} from 'office-ui-fabric-react/lib/Button';
import {Form, Icon, Input, Button, Layout} from 'antd';
import {FormProps} from "antd/lib/form/Form";
import {FormComponentProps} from 'antd/lib/form/Form';
import BusinessUnitsCascader from './BusinessUnitsCascader';
import FunctionSelector from './FunctionSelector';
import RiskSelector from './RiskSelector';
import NewHireSwitch from "./NewHireSwitch";
import PerformanceRatingSlider from "./PerformanceRatingSlider";
import PotentialRatingSlider from "./PotentialRatingSlider";
import UserRemoteSelect from "./UserSelector";

const FormItem = Form.Item;
const { Header, Content, Footer, Sider } = Layout;

function hasErrors(fieldsError) {
  return Object.keys(fieldsError).some(field => fieldsError[field]);
}

class TalentRecordForms extends React.Component<ITalentRecordFormsProps & FormComponentProps,any> {

  constructor() {
    super();
    this.state = {
      formLayout: 'vertical',
    };
  }

  handleSubmit = (e) => {
    console.log("Form Submitted")
  }

  render() {

    const {getFieldDecorator, getFieldsError, getFieldError, isFieldTouched} = this.props.form;

    const userNameError = isFieldTouched('userName') && getFieldError('userName');
    const passwordError = isFieldTouched('password') && getFieldError('password');
    const { formLayout } = this.state;
    /*const formItemLayout = formLayout === 'horizontal' ? {
      labelCol: { span: 4 },
      wrapperCol: { span: 7 },
    } : null;*/
   const formItemLayout = {
      labelCol: {
        xs: { span: 40 },
        sm: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 40 },
        sm: { span: 16 },
      },
    };

    return (
      <Form layout="vertical" onSubmit={this.handleSubmit}>
        <FormItem label="Business Unit" {...formItemLayout}>
          {getFieldDecorator('businessUnit', {
            rules: [{ required: true, message: 'Please select a business unit!' }],
          })(
            <BusinessUnitsCascader/>
          )}
        </FormItem>
        <FormItem label="Function" {...formItemLayout}>
          {getFieldDecorator('function', {
            rules: [{ required: true, message: 'Please select a function!' }],
          })(
            <FunctionSelector/>
          )}
        </FormItem>
        <FormItem label="Flight Risk" {...formItemLayout}>
          {getFieldDecorator('flightRisk', {
            rules: [{ required: true, message: 'Please select flight risk!' }],
          })(
            <RiskSelector/>
          )}
        </FormItem>
        <FormItem label="Business Risk" {...formItemLayout}>
          {getFieldDecorator('businessRisk', {
            rules: [{ required: true, message: 'Please select business risk!' }],
          })(
            <RiskSelector/>
          )}
        </FormItem>
        <FormItem label="Too New To Rate?" {...formItemLayout}>
          {getFieldDecorator('newToRate', {
            rules: [{ required: true, message: 'Too new to rate ?' }],
          })(
            <NewHireSwitch/>
          )}
        </FormItem>
        <FormItem label="Performance Rating" {...formItemLayout}>
          {getFieldDecorator('performanceRating', {
            rules: [{ required: true, message: 'Performance Rating ?' }],
          })(
            <PerformanceRatingSlider/>
          )}
        </FormItem>
        <FormItem label="Potential Rating" {...formItemLayout}>
          {getFieldDecorator('potentialRating', {
            rules: [{ required: true, message: 'Potential Rating ?' }],
          })(
            <PotentialRatingSlider/>
          )}
        </FormItem>
        <FormItem label="Employee ID" {...formItemLayout}>
          {getFieldDecorator('employeeId', {
            rules: [{ required: true, message: 'Employee ID?' }],
          })(
            <Input placeholder="Employee ID"/>
          )}
        </FormItem>
        <FormItem label="Position" {...formItemLayout}>
          {getFieldDecorator('position', {
            rules: [{ required: true, message: 'position?' }],
          })(
            <Input placeholder="Position"/>
          )}
        </FormItem>
        <FormItem label="Manager's Name" {...formItemLayout}>
          {getFieldDecorator('managerName', {
            rules: [{ required: true, message: 'manager name?' }],
          })(
            <UserRemoteSelect/>
          )}
        </FormItem>
      </Form>
    );
  }
}

const wrappedForm = Form.create<ITalentRecordFormsProps>()(TalentRecordForms);
export default wrappedForm;
