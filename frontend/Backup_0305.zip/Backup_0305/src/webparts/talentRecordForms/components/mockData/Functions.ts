const functions = [
  {value:"Finance",
  label:"Finance"},
  {value:"Procurement",
    label:"Procurement"},
  {value:"Legal & Compliance",
    label:"Legal & Compliance"},
  {value:"MarComms",
    label:"MarComms"}
]

export default functions;
