export interface ITalentRecordFormsProps {
  description: string;
}
