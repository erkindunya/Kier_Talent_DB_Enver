/* tslint:disable */
require('./TalentRecordForms.module.css');
const styles = {
  talentRecordForms: 'talentRecordForms_309b5520',
  container: 'container_309b5520',
  row: 'row_309b5520',
  column: 'column_309b5520',
  'ms-Grid': 'ms-Grid_309b5520',
  title: 'title_309b5520',
  subTitle: 'subTitle_309b5520',
  description: 'description_309b5520',
  button: 'button_309b5520',
  label: 'label_309b5520',
};

export default styles;
/* tslint:enable */