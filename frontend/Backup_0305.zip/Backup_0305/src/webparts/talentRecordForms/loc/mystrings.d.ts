declare interface ITalentRecordFormsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TalentRecordFormsWebPartStrings' {
  const strings: ITalentRecordFormsWebPartStrings;
  export = strings;
}
