/// <reference types="react" />
import * as React from 'react';
export default class FunctionSelector extends React.Component {
    handleChange: (value: any) => void;
    buildFunctionSelector: () => JSX.Element;
    render(): JSX.Element;
}
