/// <reference types="react" />
import * as React from 'react';
export default class FlightRiskSelector extends React.Component {
    handleChange: (e: any) => void;
    buildFlightRiskSelector: () => JSX.Element;
    render(): JSX.Element;
}
