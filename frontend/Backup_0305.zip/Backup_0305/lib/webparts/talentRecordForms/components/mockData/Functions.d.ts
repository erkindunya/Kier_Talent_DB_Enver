declare const functions: {
    value: string;
    label: string;
}[];
export default functions;
