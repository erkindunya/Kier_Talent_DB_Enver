declare const performanceRatings: {
    value: string;
    label: string;
}[];
export default performanceRatings;
