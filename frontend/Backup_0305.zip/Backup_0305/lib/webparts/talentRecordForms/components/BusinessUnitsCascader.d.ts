/// <reference types="react" />
import * as React from 'react';
export default class BusinessUnitsCascader extends React.Component {
    onChange(value: any): void;
    render(): JSX.Element;
}
