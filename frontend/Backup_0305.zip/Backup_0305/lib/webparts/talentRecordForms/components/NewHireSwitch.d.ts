/// <reference types="react" />
import * as React from 'react';
export default class NewHireSwitch extends React.Component {
    handleChange: () => void;
    render(): JSX.Element;
}
