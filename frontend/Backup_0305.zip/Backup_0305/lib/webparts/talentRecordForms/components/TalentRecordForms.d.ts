/// <reference types="react" />
import * as React from 'react';
import { ITalentRecordFormsProps } from './ITalentRecordFormsProps';
import { FormComponentProps } from 'antd/lib/form/Form';
declare const wrappedForm: React.ComponentClass<Pick<ITalentRecordFormsProps & FormComponentProps, "description">>;
export default wrappedForm;
