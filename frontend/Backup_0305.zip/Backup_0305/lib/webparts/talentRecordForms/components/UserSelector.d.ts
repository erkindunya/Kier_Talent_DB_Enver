/// <reference types="react" />
import * as React from 'react';
export default class UserRemoteSelect extends React.Component {
    lastFetchId: any;
    constructor(props: any);
    state: {
        data: any[];
        value: any[];
        fetching: boolean;
    };
    fetchUser: (value: any) => void;
    handleChange: (value: any) => void;
    render(): JSX.Element;
}
