/// <reference types="react" />
import * as React from 'react';
export default class PotentialRatingSlider extends React.Component {
    formatTip: (value: any) => any;
    render(): JSX.Element;
}
