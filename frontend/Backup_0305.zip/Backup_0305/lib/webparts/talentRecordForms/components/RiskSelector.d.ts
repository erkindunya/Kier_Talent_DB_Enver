/// <reference types="react" />
import * as React from 'react';
export default class RiskSelector extends React.Component {
    handleChange: (e: any) => void;
    buildRiskSelector: () => JSX.Element;
    render(): JSX.Element;
}
